﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessDayCounting
{
    public class BusinessDayCounter
    {

        #region Public methods
        /// <summary>
        /// TASK ONE:
        /// Calculates the number of weekdays in between two dates.
        /// </summary>
        /// <remarks>
        /// Weekdays are Monday, Tuesday, Wednesday, Thursday, Friday.
        /// The returned count should not include either firstDate or secondDate - e.g. between Monday 07-Oct-2013 and Wednesday 09-Oct-2013 is one weekday.
        /// If secondDate is equal to or before firstDate, return 0.
        /// </remarks>
        /// <param name="firstDate">The first date.</param>
        /// <param name="secondDate">The second date.</param>
        /// <returns>Number of weekdays</returns>
        public static int WeekdaysBetweenTwoDates(DateTime firstDate, DateTime secondDate)
        {
            return CalculateDays(firstDate, secondDate);
        }

        /// <summary>
        /// TASK TWO:
        /// Calculates the number of business days in between two dates.
        /// </summary>
        /// <remarks>
        /// Business days are Monday, Tuesday, Wednesday, Thursday, Friday, but excluding any dates which appear in the supplied list of public holidays.
        /// The returned count should not include either firstDate or secondDate - e.g. between Monday 07-Oct-2013 and Wednesday 09-Oct-2013 is one weekday.
        /// If secondDate is equal to or before firstDate, return 0.
        /// </remarks>
        /// <param name="firstDate">The first date.</param>
        /// <param name="secondDate">The second date.</param>
        /// <param name="publicHolidays">List of public holidays.</param>
        /// <returns>Number of business days</returns>
        public static int BusinessDaysBetweenTwoDates(DateTime firstDate, DateTime secondDate, IList<DateTime> publicHolidays)
        {
           
            return CalculateDays(firstDate,secondDate,publicHolidays);
        }

        /// <summary>
        /// TASK THREE:
        /// Calculates the number of business days in between two dates.
        /// </summary>
        /// <remarks>
        /// Business days are Monday, Tuesday, Wednesday, Thursday, Friday, but excluding any dates which appear in the supplied list of public holidays.
        /// The returned count should not include either firstDate or secondDate - e.g. between Monday 07-Oct-2013 and Wednesday 09-Oct-2013 is one weekday.
        /// If secondDate is equal to or before firstDate, return 0.
        /// </remarks>
        /// <param name="firstDate">The first date.</param>
        /// <param name="secondDate">The second date.</param>
        /// <param name="publicHolidays">List of public holidays.</param>
        /// <returns>Number of business days</returns>
        public static int BusinessDaysBetweenTwoDates(DateTime firstDate, DateTime secondDate, IList<PublicHoliday> publicHolidays)
        {

            return CalculateDays(firstDate, secondDate, publicHolidays);
        }
        #endregion 

        #region Private methods
        /// <summary>
        /// This function calulates number of days between two dates
        /// </summary>
        /// <param name="firstDate">first date</param>
        /// <param name="secondDate">second date</param>
        /// <returns>number of days</returns>
        private static int CalculateDays(DateTime firstDate, DateTime secondDate)
        {
            int days = 0;

            // If seond date is greater than  first date
            if (secondDate > firstDate)
            {
                //Excluding first date and second date
                firstDate = firstDate.AddDays(1);
                secondDate = secondDate.AddDays(-1);

                while (firstDate <= secondDate)
                {
                    // Adding number of days other than saturday and sunday
                    if (CheckWeekDays(firstDate.DayOfWeek))
                    {
                        //incrementing number of days
                        ++days;
                    }
                    //incrementing first date
                    firstDate = firstDate.AddDays(1);
                }
            }

            //if seond date is equal to or less than first date  days would be zero 
            //otherwise it will have the calculated number of days 
            return days;
        }

        /// <summary>
        /// This function calulates number of days between two dates excluding weekends and public holidays
        /// </summary>
        /// <param name="firstDate">first date</param>
        /// <param name="secondDate">second date</param>
        /// <param name="publicHolidays">List of public holidays.</param>
        /// <returns>number of days</returns>
        private static int CalculateDays(DateTime firstDate, DateTime secondDate, IList<DateTime> publicHolidays)
        {
            int days = 0;

            // If seond date is greater than  first date
            if (secondDate > firstDate)
            {
                //Excluding first date and second date
                firstDate = firstDate.AddDays(1);
                secondDate = secondDate.AddDays(-1);

                while (firstDate <= secondDate)
                {
                    // Adding number of days other than saturday and sunday
                    // And
                    // if its not a public holiday
                    if(CheckWeekDays(firstDate.DayOfWeek) && !CheckPublicHoliDays(firstDate,publicHolidays))
                    {
                        //incrementing number of days
                        ++days;
                    }
                    //incrementing first date
                    firstDate = firstDate.AddDays(1);
                }
            }

            //if seond date is equal to or less than first date  days would be zero 
            //otherwise it will have the calculated number of days 
            return days;
        }

        /// <summary>
        /// This function calulates number of days between two dates excluding weekends and public holidays
        /// </summary>
        /// <param name="firstDate">first date</param>
        /// <param name="secondDate">second date</param>
        /// <param name="publicHolidays">List of public holidays.</param>
        /// <returns>number of days</returns>
        private static int CalculateDays(DateTime firstDate, DateTime secondDate, IList<PublicHoliday> publicHolidays)
        {
            int days = 0;

            // If seond date is greater than  first date
            if (secondDate > firstDate)
            {
                //Excluding first date and second date
                firstDate = firstDate.AddDays(1);
                secondDate = secondDate.AddDays(-1);

                while (firstDate <= secondDate)
                {
                    // Adding number of days other than saturday and sunday
                    // And
                    // if its not a public holiday
                    if (CheckWeekDays(firstDate.DayOfWeek) && !CheckPublicHoliDays(firstDate, publicHolidays))
                    {
                        //incrementing number of days
                        ++days;
                    }
                    //incrementing first date
                    firstDate = firstDate.AddDays(1);
                }
            }

            //if seond date is equal to or less than first date  days would be zero 
            //otherwise it will have the calculated number of days 
            return days;
        }

        /// <summary>
        /// This function is used to check the week days
        /// </summary>
        /// <param name="day">day of week</param>
        /// <returns>bool</returns>
        private static bool CheckWeekDays(DayOfWeek day)
        {   
            // if days are weel days
            if (day != DayOfWeek.Saturday && day != DayOfWeek.Sunday)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// This function is used to check public holiday
        /// </summary>
        /// <param name="firstDate"> first date</param>
        /// <param name="publicHolidays">List of public holidays</param>
        /// <returns>bool</returns>
        private static bool CheckPublicHoliDays(DateTime date, IList<DateTime> publicHolidays)
        {
            bool isPublicHoliday = false;
            //checking if date is a public holiday
            isPublicHoliday = (from publicHoliday in publicHolidays where DateTime.Compare(date, publicHoliday) == 0 select true).FirstOrDefault();
            return isPublicHoliday;
        }

        /// <summary>
        /// This function is used to check public holiday
        /// </summary>
        /// <param name="firstDate"> first date</param>
        /// <param name="publicHolidays">List of public holidays</param>
        /// <returns>bool</returns>
        private static bool CheckPublicHoliDays(DateTime date, IList<PublicHoliday> publicHolidays)
        {
            bool isPublicHoliday = false;
            //checking if date is a public holiday
            isPublicHoliday = (from publicHoliday in publicHolidays where DateTime.Compare(date, publicHoliday.Date) == 0 select true).FirstOrDefault();
            return isPublicHoliday;
        }

        #endregion
    }
}
