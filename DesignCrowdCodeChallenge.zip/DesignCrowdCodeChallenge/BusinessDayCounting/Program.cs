﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessDayCounting
{
    class Program
    {
        static void Main(string[] args)
        {
            /// TASK 1: Weekday counting

            // Monday 07-Oct-2013 and Wednesday 09-Oct-2013 : should return 1
            int value1 = BusinessDayCounter.WeekdaysBetweenTwoDates(new DateTime(2013, 10, 7), new DateTime(2013, 10, 9));

            ////Saturday 05-Oct-2013 and Monday 14-Oct-2013 : should return 5
            int value2 = BusinessDayCounter.WeekdaysBetweenTwoDates(new DateTime(2013, 10, 5), new DateTime(2013, 10, 14));

            //// Monday 07-Oct-2013 and Wednesday 01-Jan-2014 : should return 61
            int value3 = BusinessDayCounter.WeekdaysBetweenTwoDates(new DateTime(2013, 10, 7), new DateTime(2014, 1, 1));

            //// Monday 07-Oct-2013 and Saturday 05-Oct-2013 : should return 0 (second date earlier than first date)
            int value4 = BusinessDayCounter.WeekdaysBetweenTwoDates(new DateTime(2013, 10, 7), new DateTime(2013, 10, 5));



            ///// TASK 2: Business day counting

            //Public holiday list containing Christmas Day, Boxing Day and New Year's Day
            List<DateTime> publicHolidays = new List<DateTime>
            {
                new DateTime(2013, 12, 25),
                new DateTime(2013, 12, 26),
                new DateTime(2014, 1, 1)
            };

            // Monday 07-Oct-2013 and Wednesday 09-Oct-2013 : should still return 1
            int value5 = BusinessDayCounter.BusinessDaysBetweenTwoDates(new DateTime(2013, 10, 7), new DateTime(2013, 10, 9), publicHolidays);

            // Tuesday 24-Dec-2013 and Friday 27-Dec-2013 : should return 0, both days are public holidays
            int value6 = BusinessDayCounter.BusinessDaysBetweenTwoDates(new DateTime(2013, 12, 24), new DateTime(2013, 12, 27), publicHolidays);

            // Monday 07-Oct-2013 and Wednesday 01-Jan-2014 : should return 59
            int value7 = BusinessDayCounter.BusinessDaysBetweenTwoDates(new DateTime(2013, 10, 7), new DateTime(2014, 1, 1), publicHolidays);




            /// TASK 3: Business day counting using custom public holiday data structure


            //Public holiday list containing Christmas Day, Boxing Day and New Year's Day
            List<PublicHoliday> complexPublicHolidays = new List<PublicHoliday> {
                new PublicHoliday {Name="Christmas",Day=25,Month=12,Year=2017 },
                new PublicHoliday {Name="Boxing day",Day=26,Month=12,Year=2017 },
                new PublicHoliday {Name="New Year",Day=1,Month=1,Year=2017 },
                new PublicHoliday {Name="Queen Birthday",OccurenceOfDay=2,DayOfWeek =1,Month=6,Year=2017 }
            };
      
            // Saturday 07-Oct-2017 and Monday 09-Oct-2017 : should still return 0
            int value8 = BusinessDayCounter.BusinessDaysBetweenTwoDates(new DateTime(2017, 10, 7), new DateTime(2017, 10, 9), complexPublicHolidays);

            // Sunday 24-Dec-2017 and Wednesday 27-Dec-2017 : should return 0, both days are public holidays
            int value9 = BusinessDayCounter.BusinessDaysBetweenTwoDates(new DateTime(2017, 12, 24), new DateTime(2017, 12, 27), complexPublicHolidays);

            // Saturday 07-Oct-2017 and Monday 01-Jan-2018 : should return 58
            int value10 = BusinessDayCounter.BusinessDaysBetweenTwoDates(new DateTime(2017, 10, 7), new DateTime(2018, 1, 1), complexPublicHolidays);


            // Thursday 08-June-2017 and Tuesday 13-Jun-2018 : should return 1
            int value11 = BusinessDayCounter.BusinessDaysBetweenTwoDates(new DateTime(2017,6, 8), new DateTime(2017, 6, 13), complexPublicHolidays);



        }
    }
}
