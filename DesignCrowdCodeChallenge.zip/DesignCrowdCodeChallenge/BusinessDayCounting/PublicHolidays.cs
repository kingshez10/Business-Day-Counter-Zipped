﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessDayCounting
{
    public class PublicHoliday
    {

       #region Data Member
       /// <summary>
        /// Name of public holiday
        /// </summary>
       public string Name { get; set; }
       /// <summary>
       /// Occurence of public holiday, it would be zero incase public holiday is on same date every year 
       /// </summary>
       public int OccurenceOfDay { get; set; }
       /// <summary>
        /// Day of Week, it would be zero incase public holiday is on same  date every year 
        /// </summary>
       public int DayOfWeek { get; set; }
       /// <summary>
       ///  Day of date
       /// </summary>
       public int Day { get; set; }
       /// <summary>
       /// Month of date
       /// </summary>
       public int Month { get; set; }
       /// <summary>
       /// Month of year
       /// </summary>
       public int Year { get; set; }
       /// <summary>
       /// Getting Public Holiday Date
       /// </summary>
       public DateTime Date
       {
            get
            {
                return GetPublicHolidayDate();
            }
       }
        #endregion

        #region Private Methods
        /// <summary>
        /// This function is used to get public holiday's date
        /// </summary>
        /// <returns>public holiday date</returns>
        private DateTime GetPublicHolidayDate()
        {
            DateTime date = DateTime.MinValue;
            if ((OccurenceOfDay == 0) && (DayOfWeek == 0))
            {
                date = new DateTime(Year, Month, Day);
                date = AdjustForWeekendHoliday(date);
            }
            else if ((OccurenceOfDay > 0) && (DayOfWeek > 0))
            {
                date = new DateTime(Year, Month, 1);
                date = date.AddDays(7 * OccurenceOfDay);
                date = date.AddDays((DayOfWeek)DayOfWeek - date.DayOfWeek);
            }
            return date;
        }

        /// <summary>
        /// This function is used to get the adjustable dates for weekend holiday
        /// </summary>
        /// <param name="date">date</param>
        /// <returns>date</returns>
        private static DateTime AdjustForWeekendHoliday(DateTime date)
        {
            if (date.DayOfWeek == System.DayOfWeek.Saturday)
            {
                return date.AddDays(2);
            }
            else if (date.DayOfWeek == System.DayOfWeek.Sunday)
            {
                return date.AddDays(1);
            }
            else
            {
                return date;
            }
        }
        #endregion
    }
}
